<!DOCTYPE html> 
<!--  Converted from HTML to WordPress with Pinegrow Web Editor. https://pinegrow.com  -->
<html <?php language_attributes(); ?>> 
    <head> 
        <meta charset="<?php bloginfo( 'charset' ); ?>"> 
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">          
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
        <meta content="Pinegrow Web Editor" name="generator">
        <?php wp_head(); ?>
    </head>     
    <body class="!no-underline bg-white dark:bg-gray-900 dark:text-white text-gray-900 <?php echo implode(' ', get_body_class()); ?>">
        <?php if( function_exists( 'wp_body_open' ) ) wp_body_open(); ?>
        <!-- Header -->
        <!-- Main Content -->
        <section>
            <nav class="bg-white" id="site-nav">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between items-center h-16">
                        <!-- Logo -->
                        <div class="shrink-0"><a class="flex items-center" href="<?php echo esc_url( home_url() ); ?>"> <?php if( get_theme_mod( 'custom_logo' ) ) : ?><img src="<?php echo PG_Image::getUrl( get_theme_mod( 'custom_logo', esc_url( get_template_directory_uri() . '/assets/images/PANTERA_WEBSITE.png' ) ), 'full' ) ?>" class="w-30" alt="Logo"><?php endif; ?> <h1 class="text-2xl font-semibold ml-5"><?php _e( '101 Starter Template', 'starter_classic_theme_tailwind' ); ?></h1> </a>
                        </div>
                        <!-- Desktop Menu -->
                        <div class="hidden sm:flex items-center space-x-8">
                            <?php if ( has_nav_menu( 'primary' ) ) : ?>
                                <?php
                                    PG_Smart_Walker_Nav_Menu::init();
                                    PG_Smart_Walker_Nav_Menu::$options['template'] = '<li class="group relative {CLASSES}" id="{ID}">
                                                <a class="flex hover:text-indigo-600 items-center text-gray-700 text-sm" {ATTRS}>{TITLE}</a>
                                                <ul class="submenu absolute left-0 mt-2 w-48 bg-white rounded-sm shadow-sm hidden z-50">
                                                  <!-- Submenu items here -->
                                                </ul>
                                              </li>';
                                    wp_nav_menu( array(
                                        'container' => '',
                                        'theme_location' => 'primary',
                                        'items_wrap' => '<ul class="%2$s flex items-center space-x-6" id="%1$s">%3$s</ul>',
                                        'walker' => new PG_Smart_Walker_Nav_Menu()
                                ) ); ?>
                            <?php endif; ?>
                        </div>
                        <!-- Mobile Menu Toggle -->
                        <div class="sm:hidden flex items-center">
                            <button id="menu-toggle" class="p-2 text-gray-500 hover:text-indigo-600 focus:outline-none">
                                <svg id="menu-icon-open" class="h-6 w-6" fill="none" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                                </svg>
                                <svg id="menu-icon-close" class="h-6 w-6 hidden" fill="none" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
                <!-- Mobile Menu Overlay -->
                <div id="mobile-menu" class="fixed top-0 left-0 w-full h-full bg-white opacity-0 pointer-events-none transition-opacity duration-200 ease-in-out z-40">
                    <ul class="flex flex-col items-center justify-center h-full space-y-6">
                        <li>
                            <a href="#" class="block font-medium text-lg hover:text-indigo-600 transition-colors"><?php _e( 'About', 'starter_classic_theme_tailwind' ); ?></a>
                        </li>
                        <li>
                            <a href="#" class="block font-medium text-lg hover:text-indigo-600 transition-colors"><?php _e( 'Contact', 'starter_classic_theme_tailwind' ); ?></a>
                        </li>
                        <li>
                            <a href="#" class="block font-medium text-lg hover:text-indigo-600 transition-colors"><?php _e( 'Blog', 'starter_classic_theme_tailwind' ); ?></a>
                        </li>
                    </ul>
                </div>
            </nav>
            <script>
const menuToggle = document.getElementById('menu-toggle');
const mobileMenu = document.getElementById('mobile-menu');
const menuIconOpen = document.getElementById('menu-icon-open');
const menuIconClose = document.getElementById('menu-icon-close');

menuToggle.addEventListener('click', () => {
  if (mobileMenu.classList.contains('opacity-0')) {
    mobileMenu.classList.remove('opacity-0', 'pointer-events-none');
    mobileMenu.classList.add('opacity-100');
    menuIconOpen.classList.add('hidden');
    menuIconClose.classList.remove('hidden');
  } else {
    mobileMenu.classList.add('opacity-0', 'pointer-events-none');
    mobileMenu.classList.remove('opacity-100');
    menuIconOpen.classList.remove('hidden');
    menuIconClose.classList.add('hidden');
  }
});

// Optional: Close menu when clicking outside links
mobileMenu.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    mobileMenu.classList.add('opacity-0', 'pointer-events-none');
    mobileMenu.classList.remove('opacity-100');
    menuIconOpen.classList.remove('hidden');
    menuIconClose.classList.add('hidden');
  });
});
</script>
        </section>
        <main>
            <section>