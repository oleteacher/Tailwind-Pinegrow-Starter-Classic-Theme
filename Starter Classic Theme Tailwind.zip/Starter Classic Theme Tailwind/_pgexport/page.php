<?php get_header(); ?>

<?php if ( !is_front_page() ) : ?>
    <div class="pb-10 pt-10"></div>
<?php endif; ?>
<?php rewind_posts(); ?>
<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <?php PG_Helper_v2::rememberShownPost(); ?>
        <div id="post-<?php the_ID(); ?>" <?php post_class( 'max-w-full mx-auto px-4 py-0' ); ?>>
            <main class="bg-white p-0 p-6 md:p-2">
                <div class="prose max-w-none text-gray-700">
                    <?php the_content(); ?>
                </div>
            </main>
        </div>
    <?php endwhile; ?>
<?php else : ?>
    <p><?php _e( 'Sorry, no posts matched your criteria.', 'starter_classic_theme_tailwind' ); ?></p>
<?php endif; ?>

<?php get_footer(); ?>