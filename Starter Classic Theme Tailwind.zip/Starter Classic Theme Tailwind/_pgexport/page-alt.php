<?php get_header(); ?>

<?php rewind_posts(); ?>
<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <?php PG_Helper_v2::rememberShownPost(); ?>
        <div id="post-<?php the_ID(); ?>" <?php post_class( 'max-w-7xl mx-auto px-4 py-8' ); ?>>
            <main class="bg-white md:p-2 p-6">
                <header class="border-b border-gray-200 pb-4 mb-6">
                    <?php if ( !is_page() ) : ?>
                        <h1 class="text-2xl md:text-3xl font-bold text-gray-800"><?php the_title(); ?></h1>
                    <?php endif; ?>
                </header>
                <div class="prose max-w-none text-gray-700 space-y-4">
                    <?php the_content(); ?>
                </div>
            </main>
        </div>
    <?php endwhile; ?>
<?php else : ?>
    <p><?php _e( 'Sorry, no posts matched your criteria.', 'starter_classic_theme_tailwind' ); ?></p>
<?php endif; ?>

<?php get_footer(); ?>