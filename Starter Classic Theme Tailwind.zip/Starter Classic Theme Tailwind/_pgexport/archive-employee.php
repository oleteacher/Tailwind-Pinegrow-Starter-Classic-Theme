<?php get_header(); ?>

<div class="gap-6 grid grid-cols-[3fr_1fr] lg:px-8 max-w-7xl mx-auto pt-24 px-4 sm:px-6">
    <!-- Blog Posts -->
    <!-- Sidebar -->
    <div>
        <h2 class="text-3xl font-bold mb-8"><?php the_archive_title() ?></h2>
        <?php rewind_posts(); ?>
        <div>
            <?php if ( have_posts() ) : ?>
                <div class="gap-8 grid lg:grid-cols-3 sm:grid-cols-2">
                    <!-- Blog Card (dynamic post) -->
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php PG_Helper_v2::rememberShownPost(); ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden hover:shadow-lg transition' ); ?>>
                            <?php if ( is_singular() ) : ?>
                                <?php echo PG_Image::getPostImage( null, 'post-thumbnail', array(
                                        'class' => 'w-full h-48 object-cover'
                                ), 'both', null ) ?>
                            <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'post-thumbnail', array(
                                            'class' => 'w-full h-48 object-cover'
                                    ), 'both', null ) ?></a>
                            <?php endif; ?>
                            <div class="p-5">
                                <div class="mb-2">
                                    <p><?php _e( 'Working Department', 'starter_classic_theme_tailwind' ); ?></p>
                                </div>
                                <?php $terms = get_the_terms( get_the_ID(), 'department' ) ?>
                                <?php if( !empty( $terms ) ) : ?>
                                    <div class="!no-underline flex flex-wrap gap-2 mb-3">
                                        <?php foreach( $terms as $term ) : ?>
                                            <?php $terms = get_the_terms( get_the_ID(), 'department' ) ?>
                                            <?php if( !empty( $terms ) ) : ?>
                                                <?php foreach( $terms as $term ) : ?>
                                                    <a class="text-xs px-2 py-1 bg-pink-100 text-pink-600 rounded-full font-medium" href="<?php echo esc_url( get_term_link( $term, 'department' ) ) ?>"><?php echo $term->name; ?></a>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                                <h3 class="font-semibold mb-2 text-xl"> <a class="!no-underline dark:hover:text-pink-400 hover:text-pink-600 transition" href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a> </h3>
                                <?php if ( is_singular() ) : ?>
                                    <p class="text-gray-600 dark:text-gray-300 text-sm mb-4"><?php echo get_the_excerpt(); ?></p>
                                <?php else : ?>
                                    <p class="text-gray-600 dark:text-gray-300 text-sm mb-4"><?php echo get_the_excerpt(); ?></p>
                                <?php endif; ?>
                                <?php if ( !is_singular() ) : ?>
                                    <a class="!font-semibold !no-underline dark:text-pink-400 hover:underline text-pink-600 text-sm" href="<?php echo esc_url( get_permalink() ); ?>"><?php _e( 'Read more →', 'starter_classic_theme_tailwind' ); ?></a>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endwhile; ?>
                    <!-- Static Card 1 -->
                    <!-- Static Card 2 -->
                </div>
            <?php else : ?>
                <p><?php _e( 'Sorry, no posts matched your criteria.', 'starter_classic_theme_tailwind' ); ?></p>
            <?php endif; ?>
        </div>
        <?php get_template_part( 'template', 'part/pagination' ); ?>
    </div>
    <div>
        <?php get_template_part( 'template', 'part/sidebar' ); ?>
    </div>
</div>                

<?php get_footer(); ?>