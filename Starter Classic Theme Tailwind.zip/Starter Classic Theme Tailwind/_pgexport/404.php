<?php get_header(); ?>

<div class="flex flex-col items-center justify-center min-h-screen bg-white px-4">
    <div class="max-w-md w-full text-center">
        <h1 class="text-9xl font-bold text-black mb-2"><?php _e( '404', 'starter_classic_theme_tailwind' ); ?></h1>
        <div class="w-16 h-1 bg-red-600 mx-auto mb-8"></div>
        <p class="text-xl mb-12 font-light"><?php _e( 'The page you are looking for cannot be found.', 'starter_classic_theme_tailwind' ); ?></p>
        <form role="search" method="get" class="w-full" action="<?php echo esc_url( home_url( '/' ) ); ?>">
            <div class="relative">
                <input type="search" name="s" placeholder="Search..." class="w-full border-b-2 border-black py-3 px-4 focus:outline-none focus:border-red-600 transition-colors bg-transparent text-lg"/>
                <button type="submit" class="absolute right-0 top-0 h-full px-4 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                </button>
            </div>
        </form>
        <div class="mt-12">
            <a href="<?php echo esc_url( home_url() ); ?>" class="inline-block border-b-2 border-black hover:border-red-600 hover:text-red-600 transition-colors py-1"><?php _e( 'Return to homepage', 'starter_classic_theme_tailwind' ); ?></a>
        </div>
    </div>
</div>            

<?php get_footer(); ?>