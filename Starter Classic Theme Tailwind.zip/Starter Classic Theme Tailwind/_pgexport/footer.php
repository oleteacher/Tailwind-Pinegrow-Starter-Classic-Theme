
            </section>
        </main>
        <!-- Footer -->
        <section class="mt-12">
            <footer class="bg-gradient-to-r from-purple-300 mb-10 ml-10 mr-10 mt-10 rounded-lg text-white to-indigo-400 via-fuchsia-400">
                <div class="lg:px-8 max-w-screen-xl mx-auto px-4 py-10 sm:px-6">
                    <div class="flex flex-col md:flex-row md:justify-between md:items-start gap-8">
                        <!-- Branding -->
                        <div class="max-w-sm"><a href="#" class="flex items-center space-x-2 mb-4"> <?php if ( get_theme_mod( 'footer_logo' ) ) : ?><?php if( get_theme_mod( 'footer_logo' ) ) : ?><img src="<?php echo PG_Image::getUrl( get_theme_mod( 'footer_logo', esc_url( get_template_directory_uri() . '/assets/images/PANTERA_WEBSITE.png' ) ), 'medium' ) ?>" alt="Flowbite Logo" class="w-30" href="<?php echo esc_url( home_url() ); ?>"/><?php endif; ?><?php endif; ?> <span class="text-2xl font-semibold" href="<?php echo esc_url( home_url() ); ?>"><?php _e( '101 Starter Theme', 'starter_classic_theme_tailwind' ); ?></span> </a>
                            <p class="text-sm text-white/80"><?php _e( 'Creating sleek components with Tailwind + Flowbite. Join our newsletter and follow us online!', 'starter_classic_theme_tailwind' ); ?></p>
                            <?php get_template_part( 'template', 'part/social' ); ?>
                        </div>
                        <!-- Newsletter -->
                        <div class="w-full md:w-1/2 lg:w-1/3">
                            <h3 class="text-lg font-semibold mb-2"><?php _e( 'Subscribe to our newsletter', 'starter_classic_theme_tailwind' ); ?></h3>
                            <form class="flex flex-col sm:flex-row gap-3">
                                <input type="email" placeholder="Your email" class="w-full px-4 py-2 rounded-md text-gray-900 focus:outline-none focus:ring-2 focus:ring-pink-300" required/>
                                <button type="submit" class="px-5 py-2 bg-white text-pink-600 rounded-md font-semibold hover:bg-pink-100 transition">
                                    <?php _e( 'Subscribe', 'starter_classic_theme_tailwind' ); ?>
                                </button>
                            </form>
                            <p class="text-xs text-white/70 mt-2"><?php _e( 'No spam, unsubscribe anytime.', 'starter_classic_theme_tailwind' ); ?></p>
                        </div>
                    </div>
                    <hr class="my-8 border-white/20"/>
                    <div class="flex flex-col md:flex-row justify-between items-center text-sm text-white/80"><span><?php _e( '© 2025', 'starter_classic_theme_tailwind' ); ?> <a href="<?php echo esc_url( home_url() ); ?>" class="font-semibold hover:underline" rel="home"><?php bloginfo( 'name' ); ?></a><?php _e( '. All Rights Reserved.', 'starter_classic_theme_tailwind' ); ?></span>
                        <?php if ( has_nav_menu( 'footer' ) ) : ?>
                            <?php
                                PG_Smart_Walker_Nav_Menu::init();
                                PG_Smart_Walker_Nav_Menu::$options['template'] = '<li class="{CLASSES}" id="{ID}"><a class="hover:underline" {ATTRS}>{TITLE}</a>
                                                            </li>';
                                wp_nav_menu( array(
                                    'container' => '',
                                    'theme_location' => 'footer',
                                    'items_wrap' => '<ul class="%2$s flex gap-4 md:mt-0 mt-4" id="%1$s">%3$s</ul>',
                                    'walker' => new PG_Smart_Walker_Nav_Menu()
                            ) ); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </footer>
        </section>
        <?php wp_footer(); ?>
    </body>
</html>
