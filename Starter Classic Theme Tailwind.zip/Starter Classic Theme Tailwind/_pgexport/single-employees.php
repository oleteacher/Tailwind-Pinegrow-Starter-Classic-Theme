<?php get_header(); ?>

<?php rewind_posts(); ?>
<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <?php PG_Helper_v2::rememberShownPost(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class( 'max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12' ); ?>>
            <header class="mb-8">
                <div class="text-sm text-gray-500 mb-2 flex items-center">
                    <time datetime="2023-11-15">
                        <?php the_time( get_option( 'date_format' ) ); ?>
                    </time>
                    <span class="mx-2">•</span>
                    <span><?php _e( 'By', 'starter_classic_theme_tailwind' ); ?> <a href="#" class="text-gray-700 hover:text-black"><?php _e( 'Jane Doe', 'starter_classic_theme_tailwind' ); ?></a></span>
                </div>
                <h1 class="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold tracking-tight mb-4"><?php the_title(); ?></h1>
                <?php $terms = get_the_terms( get_the_ID(), 'department' ) ?>
                <?php if( !empty( $terms ) ) : ?>
                    <div class="flex flex-wrap gap-2 mb-4">
                        <?php foreach( $terms as $term ) : ?>
                            <a href="<?php echo esc_url( get_term_link( $term, 'department' ) ) ?>" class="text-xs uppercase tracking-wider bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-sm"><?php echo $term->name; ?></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </header>
            <figure class="mb-10">
                <?php echo PG_Image::getPostImage( null, 'medium_large', array(
                        'class' => 'w-full h-auto object-cover aspect-video'
                ), 'both', null ) ?>
                <figcaption class="text-xs text-gray-500 mt-2">
                    <?php _e( 'Minimalist building in Zurich, Switzerland. Photo by Swiss Design Institute', 'starter_classic_theme_tailwind' ); ?>
                </figcaption>
            </figure>
            <div class="prose prose-lg max-w-none">
                <?php the_content(); ?>
            </div>
            <footer class="mt-12 pt-8 border-t border-gray-200">
                <?php if ( has_tag() ) : ?>
                    <div class="flex flex-wrap gap-2 mb-8">
                        <span class="text-sm text-gray-500"><?php _e( 'Tags:', 'starter_classic_theme_tailwind' ); ?></span>
                        <?php $terms = get_the_terms( get_the_ID(), 'post_tag' ) ?>
                        <?php if( !empty( $terms ) ) : ?>
                            <?php foreach( $terms as $term_i => $term ) : ?>
                                <a href="<?php echo esc_url( get_term_link( $term, 'post_tag' ) ) ?>" class="text-sm text-gray-700 hover:text-black"><?php echo $term->name; ?></a><?php if( $term_i < count( $terms ) - 1 ) echo ' '; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <a href="#" class="text-sm text-gray-700 hover:text-black"><?php _e( '#swissdesign', 'starter_classic_theme_tailwind' ); ?></a>
                        <a href="#" class="text-sm text-gray-700 hover:text-black"><?php _e( '#architecture', 'starter_classic_theme_tailwind' ); ?></a>
                        <a href="#" class="text-sm text-gray-700 hover:text-black"><?php _e( '#modernism', 'starter_classic_theme_tailwind' ); ?></a>
                    </div>
                <?php endif; ?>
                <div class="flex items-center">
                    <img src="https://images.unsplash.com/photo-1590332679209-630929224d52?ixid=M3wyMDkyMnwwfDF8c2VhcmNofDE0fHxhdXRob3J8ZW58MHx8fHwxNzQ0MjA0MDg2fDA&ixlib=rb-4.0.3q=85&fm=jpg&crop=faces&cs=srgb&w=1200&h=800&fit=crop" alt="Jane Doe" class="w-12 h-12 rounded-full object-cover mr-4">
                    <div>
                        <h3 class="font-medium"><?php _e( 'Jane Doe', 'starter_classic_theme_tailwind' ); ?></h3>
                        <p class="text-sm text-gray-500"><?php _e( 'Design Critic & Architectural Historian', 'starter_classic_theme_tailwind' ); ?></p>
                    </div>
                </div>
            </footer>
        </article>
    <?php endwhile; ?>
<?php else : ?>
    <p><?php _e( 'Sorry, no posts matched your criteria.', 'starter_classic_theme_tailwind' ); ?></p>
<?php endif; ?>

<?php get_footer(); ?>