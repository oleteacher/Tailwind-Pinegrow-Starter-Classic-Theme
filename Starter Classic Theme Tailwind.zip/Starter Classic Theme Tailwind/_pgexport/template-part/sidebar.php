<aside class="mt-12 space-y-8 sticky top-24 lg:mt-0">
    <!-- Categories -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4"><?php _e( '📂 Categories', 'starter_classic_theme_tailwind' ); ?></h3>
        <ul class="space-y-3">
            <li>
                <?php $terms = get_terms( array(
                        'taxonomy' => 'category',
                        'orderby' => 'name',
                        'order' => 'ASC',
                        'hide_empty' => true
                ) ) ?>
                <?php if( !empty( $terms ) && !is_wp_error( $terms ) ) : ?>
                    <?php $term_i = 0; ?>
                    <?php foreach( $terms as $term ) : ?>
                        <?php if( $term_i >= 0 && $term_i <= 15 ) : ?>
                            <a href="<?php echo esc_url( get_term_link( $term ) ); ?>" class="!no-underline block dark:hover:text-pink-400 dark:text-gray-300 hover:text-pink-600 text-gray-700 transition" rel="tag"><?php echo $term->name; ?></a>
                        <?php endif; ?>
                        <?php $term_i++; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </li>
            <li>
                <a href="#" class="block text-gray-700 dark:text-gray-300 hover:text-pink-600 dark:hover:text-pink-400 transition"><?php _e( '💻 Development', 'starter_classic_theme_tailwind' ); ?></a>
            </li>
            <li>
                <a href="#" class="block text-gray-700 dark:text-gray-300 hover:text-pink-600 dark:hover:text-pink-400 transition"><?php _e( '✍️ Writing', 'starter_classic_theme_tailwind' ); ?></a>
            </li>
            <li>
                <a href="#" class="block text-gray-700 dark:text-gray-300 hover:text-pink-600 dark:hover:text-pink-400 transition"><?php _e( '📈 Marketing', 'starter_classic_theme_tailwind' ); ?></a>
            </li>
        </ul>
    </div>
    <!-- Tags -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-4"><?php _e( '🏷️ Tags', 'starter_classic_theme_tailwind' ); ?></h3>
        <div class="flex flex-wrap gap-2">
            <?php $terms = get_terms( array(
                    'taxonomy' => 'post_tag',
                    'orderby' => 'name',
                    'order' => 'ASC',
                    'hide_empty' => true
            ) ) ?>
            <?php if( !empty( $terms ) && !is_wp_error( $terms ) ) : ?>
                <?php $term_i = 0; ?>
                <?php foreach( $terms as $term ) : ?>
                    <?php if( $term_i >= 0 && $term_i <= 20 ) : ?>
                        <a href="<?php echo esc_url( get_term_link( $term ) ); ?>" class="!no-underline bg-pink-100 font-medium px-3 py-1 rounded-full text-pink-700 text-sm transition hover:bg-pink-200" rel="tag"><?php echo $term->name; ?></a>
                    <?php endif; ?>
                    <?php $term_i++; ?>
                <?php endforeach; ?>
            <?php endif; ?><a href="#" class="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium hover:bg-blue-200 transition"><?php _e( 'CSS', 'starter_classic_theme_tailwind' ); ?></a><a href="#" class="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium hover:bg-green-200 transition"><?php _e( 'React', 'starter_classic_theme_tailwind' ); ?></a><a href="#" class="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium hover:bg-yellow-200 transition"><?php _e( 'SEO', 'starter_classic_theme_tailwind' ); ?></a><a href="#" class="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium hover:bg-purple-200 transition"><?php _e( 'Tips', 'starter_classic_theme_tailwind' ); ?></a><a href="#" class="px-3 py-1 bg-gray-200 text-gray-800 rounded-full text-sm font-medium hover:bg-gray-300 transition"><?php _e( 'Writing', 'starter_classic_theme_tailwind' ); ?></a>
        </div>
    </div>
</aside>