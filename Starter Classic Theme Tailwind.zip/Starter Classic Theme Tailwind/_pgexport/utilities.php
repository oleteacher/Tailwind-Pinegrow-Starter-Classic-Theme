<?php get_header(); ?>

<section></section>
<section data-empty-placeholder></section>        

<?php get_footer(); ?>