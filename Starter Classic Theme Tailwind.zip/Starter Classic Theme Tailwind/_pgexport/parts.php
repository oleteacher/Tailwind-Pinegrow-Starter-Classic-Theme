<?php get_header(); ?>

<section>
    <div data-empty-placeholder>
        <nav class="flex justify-center mt-12">
            <ul class="inline-flex -space-x-px text-sm">
                <!-- Prev -->
                <li><a href="#" class="px-3 py-2 ms-0 leading-tight text-gray-500 bg-white border border-gray-300 rounded-s-lg hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition"> <?php _e( 'Prev', 'starter_classic_theme_tailwind' ); ?> </a>
                </li>
                <!-- Page numbers -->
                <li><a href="#" class="px-3 py-2 leading-tight text-white bg-pink-600 border border-gray-300 hover:bg-pink-700 hover:text-white dark:border-gray-700 transition"><?php _e( '1', 'starter_classic_theme_tailwind' ); ?></a>
                </li>
                <li><a href="#" class="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition"><?php _e( '2', 'starter_classic_theme_tailwind' ); ?></a>
                </li>
                <li><a href="#" class="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition"><?php _e( '3', 'starter_classic_theme_tailwind' ); ?></a>
                </li>
                <!-- Next -->
                <li><a href="#" class="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 rounded-e-lg hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition"> <?php _e( 'Next', 'starter_classic_theme_tailwind' ); ?> </a>
                </li>
            </ul>
        </nav>
    </div>
</section>        

<?php get_footer(); ?>