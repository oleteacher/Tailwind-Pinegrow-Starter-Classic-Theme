<?php get_header(); ?>

<section>
    <div data-empty-placeholder></div>
    <div data-empty-placeholder></div>
    <div data-empty-placeholder></div>
</section>
<section>
    <div data-empty-placeholder></div>
    <div data-empty-placeholder></div>
    <div data-empty-placeholder></div>
</section>
<section>
    <div data-empty-placeholder></div>
    <div data-empty-placeholder></div>
    <div data-empty-placeholder></div>
</section>        

<?php get_footer(); ?>