<?php

        PG_Blocks_v3::register_block_type( array(
            'name' => 'starter-classic-theme-tailwind/remote-work-hero',
            'title' => __( 'Remote Work Hero', 'starter_classic_theme_tailwind' ),
            'description' => __( 'Hero section for remote work theme', 'starter_classic_theme_tailwind' ),
            'category' => 'custom_blocks',
            'render_template' => 'blocks/remote-work-hero/remote-work-hero.php',
            'supports' => array(),
            'base_url' => get_template_directory_uri(),
            'base_path' => get_template_directory(),
            'js_file' => 'blocks/remote-work-hero/remote-work-hero.js',
            'attributes' => array(
                'background_image' => array(
                    'type' => array('object', 'null'),
                    'default' => array('id' => 0, 'url' => 'https://images.unsplash.com/photo-1497493292307-31c376b6e479?ixid=M3wyMDkyMnwwfDF8c2VhcmNofDZ8fHJlbW90ZSUyMHdvcmtpbmd8ZW58MHx8fHwxNzQ0NzkyMDI3fDA&ixlib=rb-4.0.3q=85&fm=jpg&crop=faces&cs=srgb&w=1200&h=800&fit=crop', 'size' => '', 'svg' => '', 'alt' => 'Person working remotely')
                ),
                'heading' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Work From Anywhere, Succeed Everywhere'
                ),
                'description' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Embrace the freedom of remote work with our innovative solutions designed to boost your productivity and work-life balance.'
                ),
                'button_text' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Get Started'
                ),
                'button_link' => array(
                    'type' => array('object', 'null'),
                    'default' => array('post_id' => 0, 'url' => '', 'post_type' => '', 'title' => '')
                )
            ),
            'example' => array(
'background_image' => array('id' => 0, 'url' => 'https://images.unsplash.com/photo-1497493292307-31c376b6e479?ixid=M3wyMDkyMnwwfDF8c2VhcmNofDZ8fHJlbW90ZSUyMHdvcmtpbmd8ZW58MHx8fHwxNzQ0NzkyMDI3fDA&ixlib=rb-4.0.3q=85&fm=jpg&crop=faces&cs=srgb&w=1200&h=800&fit=crop', 'size' => '', 'svg' => '', 'alt' => 'Person working remotely'), 'heading' => 'Work From Anywhere, Succeed Everywhere', 'description' => 'Embrace the freedom of remote work with our innovative solutions designed to boost your productivity and work-life balance.', 'button_text' => 'Get Started', 'button_link' => array('post_id' => 0, 'url' => '', 'post_type' => '', 'title' => '')
            ),
            'dynamic' => true,
            'version' => '1.0.357'
        ) );
