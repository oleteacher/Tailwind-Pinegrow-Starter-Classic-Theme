<section <?php if(empty($_GET['context']) || $_GET['context'] !== 'edit') echo get_block_wrapper_attributes( array('class' => "h-screen m-5 relative", ) ); else echo 'data-wp-block-props="true"'; ?>> 
    <div class="absolute inset-0"> 
        <?php if ( !PG_Blocks_v3::getImageSVG( $args, 'background_image', false) && PG_Blocks_v3::getImageUrl( $args, 'background_image', 'full' ) ) : ?>
            <img src="<?php echo PG_Blocks_v3::getImageUrl( $args, 'background_image', 'full' ) ?>" alt="<?php echo PG_Blocks_v3::getImageField( $args, 'background_image', 'alt', true); ?>" class="<?php echo (PG_Blocks_v3::getImageField( $args, 'background_image', 'id', true) ? ('wp-image-' . PG_Blocks_v3::getImageField( $args, 'background_image', 'id', true)) : '') ?> h-full object-cover rounded-2xl w-full">
        <?php endif; ?>
        <?php if ( PG_Blocks_v3::getImageSVG( $args, 'background_image', false) ) : ?>
            <?php echo PG_Blocks_v3::mergeInlineSVGAttributes( PG_Blocks_v3::getImageSVG( $args, 'background_image' ), array( 'class' => 'h-full object-cover w-full rounded-2xl' ) ) ?>
        <?php endif; ?>          
    </div>     
    <div class="container flex h-full items-center mx-auto px-4 relative text-white/ z-10"> 
        <div class="bg-neutral-800/85 max-w-2xl not-prose p-5 rounded-2xl text-white"> 
            <h1 class="font-bold mb-4 md:text-6xl text-4xl"><?php echo PG_Blocks_v3::getAttribute( $args, 'heading' ) ?></h1> 
            <p class="text-lg md:text-xl mb-8"><?php echo PG_Blocks_v3::getAttribute( $args, 'description' ) ?></p> 
            <button class="bg-teal-500 hover:bg-teal-600 text-white font-bold py-3 px-8 rounded-lg transition duration-300" href="<?php echo (!empty($_GET['context']) && $_GET['context'] === 'edit') ? 'javascript:void()' : PG_Blocks_v3::getLinkUrl( $args, 'button_link' ) ?>">
                <?php echo PG_Blocks_v3::getAttribute( $args, 'button_text' ) ?>
            </button>             
        </div>         
    </div>     
</section>