
( function ( blocks, element, blockEditor ) {
    const el = element.createElement,
        registerBlockType = blocks.registerBlockType,
        ServerSideRender = PgServerSideRender3,
        InspectorControls = blockEditor.InspectorControls,
        useBlockProps = blockEditor.useBlockProps;
        
    const {__} = wp.i18n;
    const {ColorPicker, TextControl, ToggleControl, SelectControl, Panel, PanelBody, Disabled, TextareaControl, BaseControl} = wp.components;
    const {useSelect} = wp.data;
    const {RawHTML, Fragment} = element;
   
    const {InnerBlocks, URLInputButton, RichText} = wp.blockEditor;
    const useInnerBlocksProps = blockEditor.useInnerBlocksProps || blockEditor.__experimentalUseInnerBlocksProps;
    
    const propOrDefault = function(val, prop, field) {
        if(block.attributes[prop] && (val === null || val === '')) {
            return field ? block.attributes[prop].default[field] : block.attributes[prop].default;
        }
        return val;
    }
    
    const block = registerBlockType( 'starter-classic-theme-tailwind/remote-work-hero', {
        apiVersion: 2,
        title: 'Remote Work Hero',
        description: 'Hero section for remote work theme',
        icon: 'block-default',
        category: 'custom_blocks',
        keywords: [],
        supports: {},
        attributes: {
            background_image: {
                type: ['object', 'null'],
                default: {id: 0, url: 'https://images.unsplash.com/photo-1497493292307-31c376b6e479?ixid=M3wyMDkyMnwwfDF8c2VhcmNofDZ8fHJlbW90ZSUyMHdvcmtpbmd8ZW58MHx8fHwxNzQ0NzkyMDI3fDA&ixlib=rb-4.0.3q=85&fm=jpg&crop=faces&cs=srgb&w=1200&h=800&fit=crop', size: '', svg: '', alt: 'Person working remotely'},
            },
            heading: {
                type: ['string', 'null'],
                default: `Work From Anywhere, Succeed Everywhere`,
            },
            description: {
                type: ['string', 'null'],
                default: `Embrace the freedom of remote work with our innovative solutions designed to boost your productivity and work-life balance.`,
            },
            button_text: {
                type: ['string', 'null'],
                default: `Get Started`,
            },
            button_link: {
                type: ['object', 'null'],
                default: {post_id: 0, url: '', title: '', 'post_type': null},
            }
        },
        example: { attributes: { background_image: {id: 0, url: 'https://images.unsplash.com/photo-1497493292307-31c376b6e479?ixid=M3wyMDkyMnwwfDF8c2VhcmNofDZ8fHJlbW90ZSUyMHdvcmtpbmd8ZW58MHx8fHwxNzQ0NzkyMDI3fDA&ixlib=rb-4.0.3q=85&fm=jpg&crop=faces&cs=srgb&w=1200&h=800&fit=crop', size: '', svg: '', alt: 'Person working remotely'}, heading: `Work From Anywhere, Succeed Everywhere`, description: `Embrace the freedom of remote work with our innovative solutions designed to boost your productivity and work-life balance.`, button_text: `Get Started`, button_link: {post_id: 0, url: '', title: '', 'post_type': null} } },
        edit: function ( props ) {
            const blockProps = useBlockProps({ className: 'h-screen m-5 relative' });
            const setAttributes = props.setAttributes; 
            
            props.background_image = useSelect(function( select ) {
                return {
                    background_image: props.attributes.background_image.id ? select('core').getMedia(props.attributes.background_image.id) : undefined
                };
            }, [props.attributes.background_image] ).background_image;
            
            
            const innerBlocksProps = null;
            
            
            return el(Fragment, {}, [
                el('section', { ...blockProps }, [' ', ' ', el('div', { className: 'absolute inset-0' }, [' ', ' ', props.attributes.background_image && props.attributes.background_image.svg && pgCreateSVG3(RawHTML, {}, pgMergeInlineSVGAttributes(propOrDefault( props.attributes.background_image.svg, 'background_image', 'svg' ), { className: 'h-full object-cover w-full rounded-2xl' })), props.attributes.background_image && !props.attributes.background_image.svg && propOrDefault( props.attributes.background_image.url, 'background_image', 'url' ) && el('img', { src: propOrDefault( props.attributes.background_image.url, 'background_image', 'url' ), alt: propOrDefault( props.attributes.background_image?.alt, 'background_image', 'alt' ), className: 'h-full object-cover rounded-2xl w-full ' + (props.attributes.background_image.id ? ('wp-image-' + props.attributes.background_image.id) : '') }), ' ', ' ', ' ', ' ']), ' ', ' ', el('div', { className: 'container flex h-full items-center mx-auto px-4 relative text-white/ z-10' }, [' ', ' ', el('div', { className: 'bg-neutral-800/85 max-w-2xl not-prose p-5 rounded-2xl text-white' }, [' ', ' ', el(RichText, { tagName: 'h1', className: 'font-bold mb-4 md:text-6xl text-4xl', value: propOrDefault( props.attributes.heading, 'heading' ), onChange: function(val) { setAttributes( {heading: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', ' ', el(RichText, { tagName: 'p', className: 'text-lg md:text-xl mb-8', value: propOrDefault( props.attributes.description, 'description' ), onChange: function(val) { setAttributes( {description: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', ' ', el(RichText, { tagName: 'button', className: 'bg-teal-500 hover:bg-teal-600 text-white font-bold py-3 px-8 rounded-lg transition duration-300', onClick: function(e) { e.preventDefault(); }, href: propOrDefault( props.attributes.button_link.url, 'button_link', 'url' ), value: propOrDefault( props.attributes.button_text, 'button_text' ), onChange: function(val) { setAttributes( {button_text: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', ' ']), ' ', ' ']), ' ', ' ']),                        
                
                    el( InspectorControls, {},
                        [
                            
                        pgMediaImageControl('background_image', setAttributes, props, 'full', true, 'Background Image', '' ),
                                        
                            el(Panel, {},
                                el(PanelBody, {
                                    title: __('Block properties')
                                }, [
                                    
                                    el(TextControl, {
                                        value: props.attributes.heading,
                                        help: __( '' ),
                                        label: __( 'Heading' ),
                                        onChange: function(val) { setAttributes({heading: val}) },
                                        type: 'text'
                                    }),
                                    el(TextareaControl, {
                                        value: props.attributes.description,
                                        help: __( '' ),
                                        label: __( 'Description' ),
                                        onChange: function(val) { setAttributes({description: val}) },
                                    }),
                                    el(TextControl, {
                                        value: props.attributes.button_text,
                                        help: __( '' ),
                                        label: __( 'Button Text' ),
                                        onChange: function(val) { setAttributes({button_text: val}) },
                                        type: 'text'
                                    }),
                                    pgUrlControl('button_link', setAttributes, props, 'Button Link', '', null ),    
                                ])
                            )
                        ]
                    )                            

            ]);
        },

        save: function(props) {
            return null;
        }                        

    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor
);                        
