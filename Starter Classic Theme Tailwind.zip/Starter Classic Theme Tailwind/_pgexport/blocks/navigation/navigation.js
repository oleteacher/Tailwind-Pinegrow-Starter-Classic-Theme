
( function ( blocks, element, blockEditor ) {
    const el = element.createElement,
        registerBlockType = blocks.registerBlockType,
        ServerSideRender = PgServerSideRender3,
        InspectorControls = blockEditor.InspectorControls,
        useBlockProps = blockEditor.useBlockProps;
        
    const {__} = wp.i18n;
    const {ColorPicker, TextControl, ToggleControl, SelectControl, Panel, PanelBody, Disabled, TextareaControl, BaseControl} = wp.components;
    const {useSelect} = wp.data;
    const {RawHTML, Fragment} = element;
   
    const {InnerBlocks, URLInputButton, RichText} = wp.blockEditor;
    const useInnerBlocksProps = blockEditor.useInnerBlocksProps || blockEditor.__experimentalUseInnerBlocksProps;
    
    const propOrDefault = function(val, prop, field) {
        if(block.attributes[prop] && (val === null || val === '')) {
            return field ? block.attributes[prop].default[field] : block.attributes[prop].default;
        }
        return val;
    }
    
    const block = registerBlockType( 'starter-classic-theme-tailwind/navigation', {
        apiVersion: 2,
        title: 'Navigation',
        description: 'Main site navigation with dropdown menu',
        icon: 'block-default',
        category: 'custom_blocks',
        keywords: [],
        supports: {},
        attributes: {
            cta_link: {
                type: ['object', 'null'],
                default: {post_id: 0, url: '#', title: '', 'post_type': null},
            },
            cta_text: {
                type: ['string', 'null'],
                default: `Get Started`,
            },
            mobile_cta_link: {
                type: ['object', 'null'],
                default: {post_id: 0, url: '#', title: '', 'post_type': null},
            },
            mobile_cta_text: {
                type: ['string', 'null'],
                default: `Get Started`,
            }
        },
        example: { attributes: { cta_link: {post_id: 0, url: '#', title: '', 'post_type': null}, cta_text: `Get Started`, mobile_cta_link: {post_id: 0, url: '#', title: '', 'post_type': null}, mobile_cta_text: `Get Started` } },
        edit: function ( props ) {
            const blockProps = useBlockProps({ className: 'bg-white shadow', 'x-data': '{ open: false, services: false }' });
            const setAttributes = props.setAttributes; 
            
            
            const innerBlocksProps = null;
            
            
            return el(Fragment, {}, [
                el('nav', { ...blockProps }, [' ', ' ', el('div', { className: 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8' }, [' ', el('div', { className: 'flex justify-between h-16' }, [' ', el('div', { className: 'flex' }, [' ', ' ', el('div', { className: 'flex-shrink-0 flex items-center' }, [' ', el('a', { href: '' }, el('img', { src: 'https://pinegrow.com/placeholders/img17.jpg', className: 'w-25' })), ' ']), ' ', ' ', ' ', el('div', { className: 'hidden sm:ml-6 sm:flex sm:space-x-8' }, [' ', el('ul', { className: 'flex space-x-4 items-center' }, [' ', ' ', el('li', {}, el('a', { href: '#', className: 'inline-flex items-center px-1 pt-1 border-b-2 border-indigo-500 text-sm font-medium text-gray-900' }, 'Home')), ' ', el('li', {}, el('a', { href: '#', className: 'inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700' }, 'About')), ' ', ' ', ' ', el('li', { className: 'relative has-dropdown', 'x-data': '{ open: false }' }, [' ', el('button', { @click: 'open = !open', @mouseenter: 'open = true', @mouseleave: 'open = false', className: 'inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700', 'aria-haspopup': 'true' }, [' Services', ' ', el('svg', { className: 'ml-2 h-4 w-4', fill: 'currentColor', viewBox: '0 0 20 20' }, [' ', el('path', { fillRule: 'evenodd', d: 'M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z', clipRule: 'evenodd' }), ' ']), ' ']), ' ', ' ', el('ul', { 'x-show': 'open', 'x-transition': '', @mouseenter: 'open = true', @mouseleave: 'open = false', className: 'absolute left-1/2 z-10 top-full mt-1 w-screen max-w-md -translate-x-1/2 transform px-2 sm:px-0 grid gap-6 bg-white px-5 py-6 sm:gap-8 sm:p-8 rounded-lg shadow-lg ring-1 ring-black ring-opacity-5' }, [' ', ' ']), ' ']), ' ', ' ', el('li', {}, el('a', { href: '#', className: 'inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700' }, 'Blog')), ' ', el('li', {}, el('a', { href: '#', className: 'inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700' }, 'Contact')), ' ']), ' ']), ' ']), ' ', ' ', ' ', el('div', { className: 'hidden sm:ml-6 sm:flex sm:items-center' }, [' ', el(RichText, { tagName: 'a', href: propOrDefault( props.attributes.cta_link.url, 'cta_link', 'url' ), className: 'inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700', onClick: function(e) { e.preventDefault(); }, value: propOrDefault( props.attributes.cta_text, 'cta_text' ), onChange: function(val) { setAttributes( {cta_text: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ']), ' ', ' ', ' ', el('div', { className: '-mr-2 flex items-center sm:hidden' }, [' ', el('button', { @click: 'open = !open', type: 'button', className: 'inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100', 'aria-controls': 'mobile-menu', 'aria-expanded': 'false' }, [' ', el('span', { className: 'sr-only' }, 'Open main menu'), ' ', el('svg', { 'x-show': '!open', className: 'h-6 w-6', fill: 'none', viewBox: '0 0 24 24' }, [' ', el('path', { strokeLinecap: 'round', strokeLinejoin: 'round', strokeWidth: '2', d: 'M4 6h16M4 12h16M4 18h16' }), ' ']), ' ', el('svg', { 'x-show': 'open', className: 'h-6 w-6', fill: 'none', viewBox: '0 0 24 24', style: { display: 'none' } }, [' ', el('path', { strokeLinecap: 'round', strokeLinejoin: 'round', strokeWidth: '2', d: 'M6 18L18 6M6 6l12 12' }), ' ']), ' ']), ' ']), ' ']), ' ']), ' ', ' ', ' ', el('div', { 'x-show': 'open', className: 'sm:hidden', id: 'mobile-menu', style: { display: 'none' } }, [' ', el('ul', { className: 'space-y-1 pt-2 pb-3' }, [' ', el('li', {}, el('a', { href: '#', className: 'block pl-3 pr-4 py-2 border-l-4 border-indigo-500 text-base font-medium text-indigo-700 bg-indigo-50' }, 'Home')), ' ', el('li', {}, el('a', { href: '#', className: 'block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50' }, 'About')), ' ', ' ', ' ', el('li', { className: 'relative has-dropdown', 'x-data': '{ open: false }' }, [' ', el('button', { @click: 'open = !open', className: 'w-full flex items-center pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50' }, [' Services', ' ', el('svg', { className: 'ml-auto h-5 w-5', fill: 'currentColor', viewBox: '0 0 20 20' }, [' ', el('path', { fillRule: 'evenodd', d: 'M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z', clipRule: 'evenodd' }), ' ']), ' ']), ' ', el('ul', { 'x-show': 'open', 'x-transition': '', className: 'mt-2 space-y-2 pl-6' }, [' ', ' ']), ' ']), ' ', ' ', el('li', {}, el('a', { href: '#', className: 'block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50' }, 'Blog')), ' ', el('li', {}, el('a', { href: '#', className: 'block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50' }, 'Contact')), ' ']), ' ', ' ', ' ', el('div', { className: 'pt-4 pb-3 border-t border-gray-200' }, [' ', el(RichText, { tagName: 'a', href: propOrDefault( props.attributes.mobile_cta_link.url, 'mobile_cta_link', 'url' ), className: 'block w-full text-center px-4 py-2 text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 mx-4', onClick: function(e) { e.preventDefault(); }, value: propOrDefault( props.attributes.mobile_cta_text, 'mobile_cta_text' ), onChange: function(val) { setAttributes( {mobile_cta_text: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ']), ' ']), ' ']),                        
                
                    el( InspectorControls, {},
                        [
                            
                            el(Panel, {},
                                el(PanelBody, {
                                    title: __('Block properties')
                                }, [
                                    
                                    pgUrlControl('cta_link', setAttributes, props, 'cta_link', '', null ),
                                    el(TextControl, {
                                        value: props.attributes.cta_text,
                                        help: __( '' ),
                                        label: __( 'CTA Button Text' ),
                                        onChange: function(val) { setAttributes({cta_text: val}) },
                                        type: 'text'
                                    }),
                                    pgUrlControl('mobile_cta_link', setAttributes, props, 'mobile_cta_link', '', null ),
                                    el(TextControl, {
                                        value: props.attributes.mobile_cta_text,
                                        help: __( '' ),
                                        label: __( 'Mobile CTA Button Text' ),
                                        onChange: function(val) { setAttributes({mobile_cta_text: val}) },
                                        type: 'text'
                                    }),    
                                ])
                            )
                        ]
                    )                            

            ]);
        },

        save: function(props) {
            return null;
        }                        

    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor
);                        
