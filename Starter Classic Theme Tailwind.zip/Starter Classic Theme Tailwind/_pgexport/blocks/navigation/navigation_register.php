<?php

        PG_Blocks_v3::register_block_type( array(
            'name' => 'starter-classic-theme-tailwind/navigation',
            'title' => __( 'Navigation', 'starter_classic_theme_tailwind' ),
            'description' => __( 'Main site navigation with dropdown menu', 'starter_classic_theme_tailwind' ),
            'render_template' => 'blocks/navigation/navigation.php',
            'supports' => array(),
            'base_url' => get_template_directory_uri(),
            'base_path' => get_template_directory(),
            'js_file' => 'blocks/navigation/navigation.js',
            'attributes' => array(
                'cta_link' => array(
                    'type' => array('object', 'null'),
                    'default' => array('post_id' => 0, 'url' => '#', 'post_type' => '', 'title' => '')
                ),
                'cta_text' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Get Started'
                ),
                'mobile_cta_link' => array(
                    'type' => array('object', 'null'),
                    'default' => array('post_id' => 0, 'url' => '#', 'post_type' => '', 'title' => '')
                ),
                'mobile_cta_text' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Get Started'
                )
            ),
            'example' => array(
'cta_link' => array('post_id' => 0, 'url' => '#', 'post_type' => '', 'title' => ''), 'cta_text' => 'Get Started', 'mobile_cta_link' => array('post_id' => 0, 'url' => '#', 'post_type' => '', 'title' => ''), 'mobile_cta_text' => 'Get Started'
            ),
            'dynamic' => true,
            'version' => '1.0.126'
        ) );
