<nav <?php if(empty($_GET['context']) || $_GET['context'] !== 'edit') echo get_block_wrapper_attributes( array('class' => "bg-white shadow", 'x-data' => "{ open: false, services: false }", ) ); else echo 'data-wp-block-props="true"'; ?>>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex">
                <!-- Logo -->
                <div class="flex-shrink-0 flex items-center"><a href=""><?php if( get_theme_mod( 'custom_logo' ) ) : ?><img src="<?php echo PG_Image::getUrl( get_theme_mod( 'custom_logo', 'https://pinegrow.com/placeholders/img17.jpg' ), 'full' ) ?>" class="w-25"><?php endif; ?></a>
                </div>
                <!-- Desktop Menu -->
                <div class="hidden sm:ml-6 sm:flex sm:space-x-8">
                    <?php if ( has_nav_menu( 'primary' ) ) : ?>
                        <?php
                            PG_Smart_Walker_Nav_Menu::init();
                            PG_Smart_Walker_Nav_Menu::$options['template'] = '<li class="{CLASSES}" id="{ID}"><a class="inline-flex items-center px-1 pt-1 border-b-2 border-indigo-500 text-sm font-medium text-gray-900" {ATTRS}>{TITLE}</a></li>';
                            
                            PG_Smart_Walker_Nav_Menu::$options['template_item_with_sublevel'] = '<li class="relative has-dropdown {CLASSES}" x-data="{ open: false }" id="{ID}" {ATTRS}>
                                          <button @click="open = !open" @mouseenter="open = true" @mouseleave="open = false" class="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700" aria-haspopup="true">{TITLE}</button>
                            
                                          <ul x-show="open" x-transition @mouseenter="open = true" @mouseleave="open = false" cms-submenu class="absolute left-1/2 z-10 top-full mt-1 w-screen max-w-md -translate-x-1/2 transform px-2 sm:px-0 grid gap-6 bg-white px-5 py-6 sm:gap-8 sm:p-8 rounded-lg shadow-lg ring-1 ring-black ring-opacity-5">
                                            <!-- WordPress will inject submenu items here -->
                                          </ul>
                                        </li>';
                            PG_Smart_Walker_Nav_Menu::$options['template_sublevel'] = '{SUB}';
                            PG_Smart_Walker_Nav_Menu::$options['template_subitem'] = '<svg class="ml-2 h-4 w-4 {CLASSES}" fill="currentColor" viewBox="0 0 20 20" id="{ID}" {ATTRS}>
                                              <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"/>
                                            </svg>';
                            
                            wp_nav_menu( array(
                                'container' => '',
                                'theme_location' => 'primary',
                                'items_wrap' => '<ul class="%2$s flex items-center space-x-4" id="%1$s">%3$s</ul>',
                                'walker' => new PG_Smart_Walker_Nav_Menu()
                        ) ); ?>
                    <?php endif; ?>
                </div>
            </div>
            <!-- CTA Button -->
            <div class="hidden sm:ml-6 sm:flex sm:items-center"><a href="<?php echo (!empty($_GET['context']) && $_GET['context'] === 'edit') ? 'javascript:void()' : PG_Blocks_v3::getLinkUrl( $args, 'cta_link' ) ?>" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"><?php echo PG_Blocks_v3::getAttribute( $args, 'cta_text' ) ?></a>
            </div>
            <!-- Mobile Menu Toggle -->
            <div class="-mr-2 flex items-center sm:hidden">
                <button @click="open = !open" type="button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100" aria-controls="mobile-menu" aria-expanded="false"><span class="sr-only"><?php _e( 'Open main menu', 'starter_classic_theme_tailwind' ); ?></span>
                    <svg x-show="!open" class="h-6 w-6" fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                    <svg x-show="open" class="h-6 w-6" fill="none" viewBox="0 0 24 24" style="display: none;">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
        </div>
    </div>
    <!-- Mobile Menu -->
    <div x-show="open" class="sm:hidden" id="mobile-menu" style="display: none;">
        <?php if ( has_nav_menu( 'primary' ) ) : ?>
            <?php
                PG_Smart_Walker_Nav_Menu::init();
                PG_Smart_Walker_Nav_Menu::$options['template'] = '<li class="{CLASSES}" id="{ID}"><a class="block pl-3 pr-4 py-2 border-l-4 border-indigo-500 text-base font-medium text-indigo-700 bg-indigo-50" {ATTRS}>{TITLE}</a></li>';
                
                PG_Smart_Walker_Nav_Menu::$options['template_item_with_sublevel'] = '<li class="relative has-dropdown {CLASSES}" x-data="{ open: false }" id="{ID}" {ATTRS}>
                        <button @click="open = !open" class="w-full flex items-center pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:bg-gray-50">{TITLE}</button>
                        <ul x-show="open" x-transition cms-submenu class="mt-2 space-y-2 pl-6">
                          <!-- WordPress submenu injected here -->
                        </ul>
                      </li>';
                PG_Smart_Walker_Nav_Menu::$options['template_sublevel'] = '{SUB}';
                PG_Smart_Walker_Nav_Menu::$options['template_subitem'] = '<svg class="ml-auto h-5 w-5 {CLASSES}" fill="currentColor" viewBox="0 0 20 20" id="{ID}" {ATTRS}>
                            <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"/>
                          </svg>';
                
                wp_nav_menu( array(
                    'container' => '',
                    'theme_location' => 'primary',
                    'items_wrap' => '<ul class="%2$s pb-3 pt-2 space-y-1" id="%1$s">%3$s</ul>',
                    'walker' => new PG_Smart_Walker_Nav_Menu()
            ) ); ?>
        <?php endif; ?>
        <!-- Mobile CTA -->
        <div class="pt-4 pb-3 border-t border-gray-200"><a href="<?php echo (!empty($_GET['context']) && $_GET['context'] === 'edit') ? 'javascript:void()' : PG_Blocks_v3::getLinkUrl( $args, 'mobile_cta_link' ) ?>" class="block w-full text-center px-4 py-2 text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 mx-4"><?php echo PG_Blocks_v3::getAttribute( $args, 'mobile_cta_text' ) ?></a>
        </div>
    </div>
</nav>