
( function ( blocks, element, blockEditor ) {
    const el = element.createElement,
        registerBlockType = blocks.registerBlockType,
        ServerSideRender = PgServerSideRender3,
        InspectorControls = blockEditor.InspectorControls,
        useBlockProps = blockEditor.useBlockProps;
        
    const {__} = wp.i18n;
    const {ColorPicker, TextControl, ToggleControl, SelectControl, Panel, PanelBody, Disabled, TextareaControl, BaseControl} = wp.components;
    const {useSelect} = wp.data;
    const {RawHTML, Fragment} = element;
   
    const {InnerBlocks, URLInputButton, RichText} = wp.blockEditor;
    const useInnerBlocksProps = blockEditor.useInnerBlocksProps || blockEditor.__experimentalUseInnerBlocksProps;
    
    const propOrDefault = function(val, prop, field) {
        if(block.attributes[prop] && (val === null || val === '')) {
            return field ? block.attributes[prop].default[field] : block.attributes[prop].default;
        }
        return val;
    }
    
    const block = registerBlockType( 'starter-classic-theme-tailwind/service-item', {
        apiVersion: 2,
        title: 'Service Item',
        description: '',
        icon: 'block-default',
        category: 'custom_blocks',
        parent: [ 'starter-classic-theme-tailwind/services' ],

        keywords: [],
        supports: {},
        attributes: {
            icon_bg: {
                type: ['string', 'null'],
                default: '',
            },
            icon: {
                type: ['object', 'null'],
                default: {id: 0, url: '', size: '', svg: `<svg class="h-8 w-8 text-blue-500" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"> 
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/> 
</svg>`, alt: null},
            },
            title: {
                type: ['string', 'null'],
                default: `Virtual Workspace Setup`,
            },
            description: {
                type: ['string', 'null'],
                default: `We help you create an optimized digital environment with all the tools you need to work efficiently from anywhere.`,
            },
            link_color: {
                type: ['string', 'null'],
                default: '',
            },
            link: {
                type: ['object', 'null'],
                default: {post_id: 0, url: '#', title: '', 'post_type': null},
            },
            link_text: {
                type: ['string', 'null'],
                default: `Learn more →`,
            }
        },
        example: { attributes: { icon_bg: '', icon: {id: 0, url: '', size: '', svg: `<svg class="h-8 w-8 text-blue-500" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"> 
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/> 
</svg>`, alt: null}, title: `Virtual Workspace Setup`, description: `We help you create an optimized digital environment with all the tools you need to work efficiently from anywhere.`, link_color: '', link: {post_id: 0, url: '#', title: '', 'post_type': null}, link_text: `Learn more →` } },
        edit: function ( props ) {
            const blockProps = useBlockProps({ className: 'bg-white p-8 rounded-lg shadow-sm hover:shadow-md transition duration-300' });
            const setAttributes = props.setAttributes; 
            
            props.icon = useSelect(function( select ) {
                return {
                    icon: props.attributes.icon.id ? select('core').getMedia(props.attributes.icon.id) : undefined
                };
            }, [props.attributes.icon] ).icon;
            
            
            const innerBlocksProps = null;
            
            
            return el(Fragment, {}, [
                el('div', { ...blockProps }, [' ', ' ', el('div', { className: 'bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6 ' + propOrDefault( props.attributes.icon_bg, 'icon_bg' ) }, [' ', ' ', props.attributes.icon && !props.attributes.icon.url && propOrDefault( props.attributes.icon.svg, 'icon', 'svg' ) && pgCreateSVG3(RawHTML, {}, pgMergeInlineSVGAttributes(propOrDefault( props.attributes.icon.svg, 'icon', 'svg' ), { className: 'h-8 w-8 text-blue-500' })), props.attributes.icon && props.attributes.icon.url && el('img', { className: 'h-8 w-8 text-blue-500 ' + (props.attributes.icon.id ? ('wp-image-' + props.attributes.icon.id) : ''), src: propOrDefault( props.attributes.icon.url, 'icon', 'url' ) }), ' ', ' ']), ' ', ' ', el(RichText, { tagName: 'h3', className: 'text-xl font-bold mb-3', value: propOrDefault( props.attributes.title, 'title' ), onChange: function(val) { setAttributes( {title: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', ' ', el(RichText, { tagName: 'p', className: 'text-slate-600 mb-4', value: propOrDefault( props.attributes.description, 'description' ), onChange: function(val) { setAttributes( {description: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', el(RichText, { tagName: 'a', href: propOrDefault( props.attributes.link.url, 'link', 'url' ), className: 'text-blue-500 font-medium hover:text-blue-700 ' + propOrDefault( props.attributes.link_color, 'link_color' ), onClick: function(e) { e.preventDefault(); }, value: propOrDefault( props.attributes.link_text, 'link_text' ), onChange: function(val) { setAttributes( {link_text: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', ' ']),                        
                
                    el( InspectorControls, {},
                        [
                            
                        pgMediaImageControl('icon', setAttributes, props, 'full', true, 'Icon SVG', '' ),
                                        
                            el(Panel, {},
                                el(PanelBody, {
                                    title: __('Block properties')
                                }, [
                                    
                                    el(SelectControl, {
                                        value: props.attributes.icon_bg,
                                        label: __( 'Icon Background Color' ),
                                        onChange: function(val) { setAttributes({icon_bg: val}) },
                                        options: [
                                            { value: '', label: '-' }
                                        ]
                                    }),
                                    el(TextControl, {
                                        value: props.attributes.title,
                                        help: __( '' ),
                                        label: __( 'Service Title' ),
                                        onChange: function(val) { setAttributes({title: val}) },
                                        type: 'text'
                                    }),
                                    el(TextControl, {
                                        value: props.attributes.description,
                                        help: __( '' ),
                                        label: __( 'Service Description' ),
                                        onChange: function(val) { setAttributes({description: val}) },
                                        type: 'text'
                                    }),
                                    el(SelectControl, {
                                        value: props.attributes.link_color,
                                        label: __( 'Link Color' ),
                                        onChange: function(val) { setAttributes({link_color: val}) },
                                        options: [
                                            { value: '', label: '-' }
                                        ]
                                    }),
                                    pgUrlControl('link', setAttributes, props, 'Learn More Link', '', null ),
                                    el(TextControl, {
                                        value: props.attributes.link_text,
                                        help: __( '' ),
                                        label: __( 'Link Text' ),
                                        onChange: function(val) { setAttributes({link_text: val}) },
                                        type: 'text'
                                    }),    
                                ])
                            )
                        ]
                    )                            

            ]);
        },

        save: function(props) {
            return null;
        }                        

    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor
);                        
