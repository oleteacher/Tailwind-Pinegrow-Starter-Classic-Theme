<div <?php if(empty($_GET['context']) || $_GET['context'] !== 'edit') echo get_block_wrapper_attributes( array('class' => "bg-white p-8 rounded-lg shadow-sm hover:shadow-md transition duration-300", ) ); else echo 'data-wp-block-props="true"'; ?>> 
    <div class="bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6 <?php echo PG_Blocks_v3::getAttribute( $args, 'icon_bg' ) ?>"> 
        <?php if ( !PG_Blocks_v3::getImageUrl( $args, 'icon', 'full', false ) && PG_Blocks_v3::getImageSVG( $args, 'icon' ) ) : ?>
            <?php echo PG_Blocks_v3::mergeInlineSVGAttributes( PG_Blocks_v3::getImageSVG( $args, 'icon' ), array( 'class' => 'h-8 w-8 text-blue-500' ) ) ?>
        <?php endif; ?>
        <?php if ( PG_Blocks_v3::getImageUrl( $args, 'icon', 'full', false ) ) : ?>
            <img src="<?php echo PG_Blocks_v3::getImageUrl( $args, 'icon', 'full' ); ?>" class="h-8 w-8 text-blue-500 <?php echo (PG_Blocks_v3::getImageField( $args, 'icon', 'id', true) ? ('wp-image-' . PG_Blocks_v3::getImageField( $args, 'icon', 'id', true)) : '') ?>"/>
        <?php endif; ?> 
    </div>     
    <h3 class="text-xl font-bold mb-3"><?php echo PG_Blocks_v3::getAttribute( $args, 'title' ) ?></h3> 
    <p class="text-slate-600 mb-4"><?php echo PG_Blocks_v3::getAttribute( $args, 'description' ) ?></p><a href="<?php echo (!empty($_GET['context']) && $_GET['context'] === 'edit') ? 'javascript:void()' : PG_Blocks_v3::getLinkUrl( $args, 'link' ) ?>" class="text-blue-500 font-medium hover:text-blue-700 <?php echo PG_Blocks_v3::getAttribute( $args, 'link_color' ) ?>"><?php echo PG_Blocks_v3::getAttribute( $args, 'link_text' ) ?></a> 
</div>