<?php

        PG_Blocks_v3::register_block_type( array(
            'name' => 'starter-classic-theme-tailwind/service-item',
            'title' => __( 'Service Item', 'starter_classic_theme_tailwind' ),
            'render_template' => 'blocks/service-item/service-item.php',
            'supports' => array(),
            'base_url' => get_template_directory_uri(),
            'base_path' => get_template_directory(),
            'js_file' => 'blocks/service-item/service-item.js',
            'attributes' => array(
                'icon_bg' => array(
                    'type' => array('string', 'null'),
                    'default' => ''
                ),
                'icon' => array(
                    'type' => array('object', 'null'),
                    'default' => array('id' => 0, 'url' => '', 'size' => '', 'svg' => '<svg class="h-8 w-8 text-blue-500" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"> 
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/> 
</svg>', 'alt' => null)
                ),
                'title' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Virtual Workspace Setup'
                ),
                'description' => array(
                    'type' => array('string', 'null'),
                    'default' => 'We help you create an optimized digital environment with all the tools you need to work efficiently from anywhere.'
                ),
                'link_color' => array(
                    'type' => array('string', 'null'),
                    'default' => ''
                ),
                'link' => array(
                    'type' => array('object', 'null'),
                    'default' => array('post_id' => 0, 'url' => '#', 'post_type' => '', 'title' => '')
                ),
                'link_text' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Learn more →'
                )
            ),
            'example' => array(
'icon_bg' => '', 'icon' => array('id' => 0, 'url' => '', 'size' => '', 'svg' => '<svg class="h-8 w-8 text-blue-500" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"> 
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/> 
</svg>', 'alt' => null), 'title' => 'Virtual Workspace Setup', 'description' => 'We help you create an optimized digital environment with all the tools you need to work efficiently from anywhere.', 'link_color' => '', 'link' => array('post_id' => 0, 'url' => '#', 'post_type' => '', 'title' => ''), 'link_text' => 'Learn more →'
            ),
            'dynamic' => true,
            'version' => '1.0.357'
        ) );
