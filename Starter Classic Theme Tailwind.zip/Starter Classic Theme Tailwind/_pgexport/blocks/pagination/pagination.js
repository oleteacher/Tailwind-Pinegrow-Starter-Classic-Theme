
( function ( blocks, element, blockEditor ) {
    const el = element.createElement,
        registerBlockType = blocks.registerBlockType,
        ServerSideRender = PgServerSideRender3,
        InspectorControls = blockEditor.InspectorControls,
        useBlockProps = blockEditor.useBlockProps;
        
    const {__} = wp.i18n;
    const {ColorPicker, TextControl, ToggleControl, SelectControl, Panel, PanelBody, Disabled, TextareaControl, BaseControl} = wp.components;
    const {useSelect} = wp.data;
    const {RawHTML, Fragment} = element;
   
    const {InnerBlocks, URLInputButton, RichText} = wp.blockEditor;
    const useInnerBlocksProps = blockEditor.useInnerBlocksProps || blockEditor.__experimentalUseInnerBlocksProps;
    
    const propOrDefault = function(val, prop, field) {
        if(block.attributes[prop] && (val === null || val === '')) {
            return field ? block.attributes[prop].default[field] : block.attributes[prop].default;
        }
        return val;
    }
    
    const block = registerBlockType( 'starter-classic-theme-tailwind/pagination', {
        apiVersion: 2,
        title: 'Pagination',
        description: 'Navigation pagination for posts or products',
        icon: 'block-default',
        category: 'custom_blocks',
        keywords: [],
        supports: {},
        attributes: {
        },
        example: { attributes: {  } },
        edit: function ( props ) {
            const blockProps = useBlockProps({});
            const setAttributes = props.setAttributes; 
            
            
            const innerBlocksProps = null;
            
            
            return el(Fragment, {}, [
                el('div', { ...blockProps }, [' ', el('nav', { className: 'flex justify-center mt-12' }, [' ', ' ', el('ul', { className: 'inline-flex -space-x-px text-sm' }, [' ', ' ', ' ', ' ', ' ', ' ', el('li', {}, [' ', el('a', { href: '#', className: 'px-3 py-2 ms-0 leading-tight text-gray-500 bg-white border border-gray-300 rounded-s-lg hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition' }, ' Prev '), ' ', ' ']), ' ', ' ', ' ', ' ', ' ', ' ', el('li', {}, [' ', el('a', { href: '#', className: 'px-3 py-2 leading-tight text-white bg-pink-600 border border-gray-300 hover:bg-pink-700 hover:text-white dark:border-gray-700 transition' }, '1'), ' ', ' ']), ' ', ' ', ' ', el('li', {}, [' ', el('a', { href: '#', className: 'px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition' }, '2'), ' ', ' ']), ' ', ' ', ' ', el('li', {}, [' ', el('a', { href: '#', className: 'px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition' }, '3'), ' ', ' ']), ' ', ' ', ' ', ' ', ' ', ' ', el('li', {}, [' ', el('a', { href: '#', className: 'px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 rounded-e-lg hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition' }, ' Next '), ' ', ' ']), ' ', ' ']), ' ', ' ']), ' ']),                        
                
            ]);
        },

        save: function(props) {
            return null;
        }                        

    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor
);                        
