<div <?php if(empty($_GET['context']) || $_GET['context'] !== 'edit') echo get_block_wrapper_attributes( array() ); else echo 'data-wp-block-props="true"'; ?>>
    <?php if ( PG_Pagination::isPaginated() ) : ?>
        <nav class="flex justify-center mt-12"> 
            <ul class="inline-flex -space-x-px text-sm"> 
                <!-- Prev -->                 
                <?php for( $page_num = 1; $page_num <= PG_Pagination::getMaxPages(); $page_num++) : ?>
                    <?php if( $page_num == PG_Pagination::getCurrentPage() ) : ?>
                        <a href="<?php echo esc_url( get_pagenum_link( $page_num ) ) ?>" class="px-3 py-2 leading-tight text-white bg-pink-600 border border-gray-300 hover:bg-pink-700 hover:text-white dark:border-gray-700 transition" cms-block-field-value="bg-pink-600"><?php echo $page_num ?></a>
                    <?php else : ?>
                        <li class="<?php if( $page_num == PG_Pagination::getCurrentPage() ) echo 'active'; ?>"> <a class="<?php if(!( PG_Pagination::getCurrentPage() > 1 )) echo 'disabled'; ?> bg-white border border-gray-300 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700 dark:hover:text-white dark:text-gray-400 hover:bg-pink-100 hover:text-pink-600 leading-tight ms-0 px-3 py-2 rounded-s-lg text-gray-500 transition" <?php echo PG_Pagination::getPreviousHrefAttribute(); ?> href="<?php echo esc_url( get_pagenum_link( $page_num ) ) ?>"><?php echo $page_num ?></a> 
                        </li>
                    <?php endif; ?>
                <?php endfor; ?> 
                <!-- Page numbers -->                 
                <li>                      
</li>                 
                <li> <a href="#" class="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition"><?php _e( '2', 'starter_classic_theme_tailwind' ); ?></a> 
                </li>                 
                <li> <a href="#" class="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-pink-100 hover:text-pink-600 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white transition"><?php _e( '3', 'starter_classic_theme_tailwind' ); ?></a> 
                </li>                 
                <!-- Next -->                 
                <li> <a class="<?php if(!( PG_Pagination::getCurrentPage() < PG_Pagination::getMaxPages() )) echo 'disabled'; ?> bg-white border border-gray-300 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700 dark:hover:text-white dark:text-gray-400 hover:bg-pink-100 hover:text-pink-600 leading-tight px-3 py-2 rounded-e-lg text-gray-500 transition" <?php echo PG_Pagination::getNextHrefAttribute(); ?>> <?php _e( 'Next', 'starter_classic_theme_tailwind' ); ?> </a> 
                </li>                 
            </ul>             
        </nav>
    <?php endif; ?>
</div>