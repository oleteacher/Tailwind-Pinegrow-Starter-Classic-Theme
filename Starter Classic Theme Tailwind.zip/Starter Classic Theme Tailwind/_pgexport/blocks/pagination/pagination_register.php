<?php

        PG_Blocks_v3::register_block_type( array(
            'name' => 'starter-classic-theme-tailwind/pagination',
            'title' => __( 'Pagination', 'starter_classic_theme_tailwind' ),
            'description' => __( 'Navigation pagination for posts or products', 'starter_classic_theme_tailwind' ),
            'render_template' => 'blocks/pagination/pagination.php',
            'supports' => array(),
            'base_url' => get_template_directory_uri(),
            'base_path' => get_template_directory(),
            'js_file' => 'blocks/pagination/pagination.js',
            'attributes' => array(

            ),
            'example' => array(

            ),
            'dynamic' => true,
            'version' => '1.0.16'
        ) );
