<nav <?php if(empty($_GET['context']) || $_GET['context'] !== 'edit') echo get_block_wrapper_attributes( array('class' => "bg-white", ) ); else echo 'data-wp-block-props="true"'; ?>> 
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> 
        <div class="flex justify-between h-16 items-center"> 
            <!-- Logo + Site Title -->             
            <div class="flex-shrink-0 flex items-center"> <a class="flex items-center" href="<?php echo esc_url( home_url() ); ?>">  <?php if ( !PG_Blocks_v3::getImageSVG( $args, 'logo', false) && PG_Blocks_v3::getImageUrl( $args, 'logo', 'full' ) ) : ?><?php if( get_theme_mod( 'custom_logo' ) ) : ?><img src="<?php echo PG_Blocks_v3::getImageUrl( $args, 'logo', 'full' ) ?>" class="<?php echo (PG_Blocks_v3::getImageField( $args, 'logo', 'id', true) ? ('wp-image-' . PG_Blocks_v3::getImageField( $args, 'logo', 'id', true)) : '') ?> w-30" alt="<?php echo PG_Blocks_v3::getImageField( $args, 'logo', 'alt', true); ?>"><?php endif; ?><?php endif; ?><?php if ( PG_Blocks_v3::getImageSVG( $args, 'logo', false) ) : ?><?php echo PG_Blocks_v3::mergeInlineSVGAttributes( PG_Blocks_v3::getImageSVG( $args, 'logo' ), array( 'class' => 'w-30' ) ) ?><?php endif; ?>  <h1 class="text-2xl font-semibold ml-5 pr-5 <?php echo PG_Blocks_v3::getAttribute( $args, 'site_title_display' ) ?>"><?php bloginfo( 'name' ); ?></h1>  </a> 
            </div>             
            <!-- Desktop Navigation -->             
            <div class="hidden sm:flex sm:items-center sm:space-x-8"> 
                <?php if ( has_nav_menu( 'primary' ) ) : ?>
                    <?php
                        PG_Smart_Walker_Nav_Menu::init();
                        PG_Smart_Walker_Nav_Menu::$options['template'] = '<li class="has-dropdown group relative {CLASSES}" id="{ID}"> 
                                    <a class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-gray-900 px-3 py-2" {ATTRS}>{TITLE}
                                      <svg class="ml-2 h-4 w-4" version xmlns viewBox="0 0 20 20" xml:space fill="currentColor" stroke> <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"/> </svg> 
                                    </a>  
                                    <!-- WordPress Submenu Injection Point --> 
                                    <ul class="sub-menu hidden absolute left-0 mt-2 w-64 bg-white shadow-lg ring-1 ring-black ring-opacity-5 rounded-md z-50 py-2 group-hover:block"> 
                                      <!-- WordPress submenu items go here --> 
                                    </ul> 
                                  </li>';
                        
                        PG_Smart_Walker_Nav_Menu::$options['template_item_with_sublevel'] = '<li class="has-dropdown group relative {CLASSES}" id="{ID}"> 
                                    <a class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-gray-900 px-3 py-2" {ATTRS}>{TITLE}</a>  
                                    <!-- WordPress Submenu Injection Point --> 
                                    <ul cms-submenu class="sub-menu hidden absolute left-0 mt-2 w-64 bg-white shadow-lg ring-1 ring-black ring-opacity-5 rounded-md z-50 py-2 group-hover:block"> 
                                      <!-- WordPress submenu items go here --> 
                                    </ul> 
                                  </li>';
                        PG_Smart_Walker_Nav_Menu::$options['template_sublevel'] = '{SUB}';
                        PG_Smart_Walker_Nav_Menu::$options['template_subitem'] = '<svg class="ml-2 h-4 w-4 {CLASSES}" version xmlns viewBox="0 0 20 20" xml:space fill="currentColor" stroke id="{ID}" {ATTRS}> <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"/> </svg>';
                        
                        wp_nav_menu( array(
                            'container' => '',
                            'theme_location' => 'primary',
                            'items_wrap' => '<ul class="%2$s flex items-center space-x-4" id="%1$s">%3$s</ul>',
                            'walker' => new PG_Smart_Walker_Nav_Menu()
                    ) ); ?>
                <?php endif; ?> 
            </div>             
            <!-- CTA -->             
            <div class="hidden sm:flex sm:items-center ml-6"> <a href="<?php echo (!empty($_GET['context']) && $_GET['context'] === 'edit') ? 'javascript:void()' : PG_Blocks_v3::getLinkUrl( $args, 'cta_link' ) ?>" class="px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"><?php echo PG_Blocks_v3::getAttribute( $args, 'cta_text' ) ?></a> 
            </div>             
        </div>         
    </div>     
</nav>