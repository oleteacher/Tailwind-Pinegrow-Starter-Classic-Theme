<?php

        PG_Blocks_v3::register_block_type( array(
            'name' => 'starter-classic-theme-tailwind/main-navigation',
            'title' => __( 'Main Navigation', 'starter_classic_theme_tailwind' ),
            'description' => __( 'Site header with logo, menu and call to action button', 'starter_classic_theme_tailwind' ),
            'category' => 'custom_blocks',
            'render_template' => 'blocks/main-navigation/main-navigation.php',
            'supports' => array(),
            'base_url' => get_template_directory_uri(),
            'base_path' => get_template_directory(),
            'js_file' => 'blocks/main-navigation/main-navigation.js',
            'attributes' => array(
                'logo' => array(
                    'type' => array('object', 'null'),
                    'default' => array('id' => 0, 'url' => esc_url( get_template_directory_uri() . '/assets/images/PANTERA_WEBSITE.png' ), 'size' => '', 'svg' => '', 'alt' => null)
                ),
                'site_title_display' => array(
                    'type' => array('string', 'null'),
                    'default' => ''
                ),
                'cta_link' => array(
                    'type' => array('object', 'null'),
                    'default' => array('post_id' => 0, 'url' => '#', 'post_type' => '', 'title' => '')
                ),
                'cta_text' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Get Started'
                )
            ),
            'example' => array(
'logo' => array('id' => 0, 'url' => esc_url( get_template_directory_uri() . '/assets/images/PANTERA_WEBSITE.png' ), 'size' => '', 'svg' => '', 'alt' => null), 'site_title_display' => '', 'cta_link' => array('post_id' => 0, 'url' => '#', 'post_type' => '', 'title' => ''), 'cta_text' => 'Get Started'
            ),
            'dynamic' => true,
            'version' => '1.0.285'
        ) );
