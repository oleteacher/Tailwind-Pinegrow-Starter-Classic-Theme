
( function ( blocks, element, blockEditor ) {
    const el = element.createElement,
        registerBlockType = blocks.registerBlockType,
        ServerSideRender = PgServerSideRender3,
        InspectorControls = blockEditor.InspectorControls,
        useBlockProps = blockEditor.useBlockProps;
        
    const {__} = wp.i18n;
    const {ColorPicker, TextControl, ToggleControl, SelectControl, Panel, PanelBody, Disabled, TextareaControl, BaseControl} = wp.components;
    const {useSelect} = wp.data;
    const {RawHTML, Fragment} = element;
   
    const {InnerBlocks, URLInputButton, RichText} = wp.blockEditor;
    const useInnerBlocksProps = blockEditor.useInnerBlocksProps || blockEditor.__experimentalUseInnerBlocksProps;
    
    const propOrDefault = function(val, prop, field) {
        if(block.attributes[prop] && (val === null || val === '')) {
            return field ? block.attributes[prop].default[field] : block.attributes[prop].default;
        }
        return val;
    }
    
    const block = registerBlockType( 'starter-classic-theme-tailwind/main-navigation', {
        apiVersion: 2,
        title: 'Main Navigation',
        description: 'Site header with logo, menu and call to action button',
        icon: 'block-default',
        category: 'custom_blocks',
        keywords: [],
        supports: {},
        attributes: {
            logo: {
                type: ['object', 'null'],
                default: {id: 0, url: (pg_project_data_starter_classic_theme_tailwind ? pg_project_data_starter_classic_theme_tailwind.url : '') + 'assets/images/PANTERA_WEBSITE.png', size: '', svg: '', alt: null},
            },
            site_title_display: {
                type: ['string', 'null'],
                default: '',
            },
            cta_link: {
                type: ['object', 'null'],
                default: {post_id: 0, url: '#', title: '', 'post_type': null},
            },
            cta_text: {
                type: ['string', 'null'],
                default: `Get Started`,
            }
        },
        example: { attributes: { logo: {id: 0, url: (pg_project_data_starter_classic_theme_tailwind ? pg_project_data_starter_classic_theme_tailwind.url : '') + 'assets/images/PANTERA_WEBSITE.png', size: '', svg: '', alt: null}, site_title_display: '', cta_link: {post_id: 0, url: '#', title: '', 'post_type': null}, cta_text: `Get Started` } },
        edit: function ( props ) {
            const blockProps = useBlockProps({ className: 'bg-white' });
            const setAttributes = props.setAttributes; 
            
            props.logo = useSelect(function( select ) {
                return {
                    logo: props.attributes.logo.id ? select('core').getMedia(props.attributes.logo.id) : undefined
                };
            }, [props.attributes.logo] ).logo;
            
            
            const innerBlocksProps = null;
            
            
            return el(Fragment, {}, [
                el('nav', { ...blockProps }, [' ', ' ', el('div', { className: 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8' }, [' ', ' ', el('div', { className: 'flex justify-between h-16 items-center' }, [' ', ' ', ' ', ' ', el('div', { className: 'flex-shrink-0 flex items-center' }, [' ', ' ', el('a', { className: 'flex items-center' }, [' ', ' ', props.attributes.logo && props.attributes.logo.svg && pgCreateSVG3(RawHTML, {}, pgMergeInlineSVGAttributes(propOrDefault( props.attributes.logo.svg, 'logo', 'svg' ), { className: 'w-30' })), props.attributes.logo && !props.attributes.logo.svg && propOrDefault( props.attributes.logo.url, 'logo', 'url' ) && el('img', { src: propOrDefault( props.attributes.logo.url, 'logo', 'url' ), className: 'w-30 ' + (props.attributes.logo.id ? ('wp-image-' + props.attributes.logo.id) : ''), alt: propOrDefault( props.attributes.logo?.alt, 'logo', 'alt' ) }), ' ', ' ', el('h1', { className: 'text-2xl font-semibold ml-5 pr-5 ' + propOrDefault( props.attributes.site_title_display, 'site_title_display' ) }, '101 Starter Template'), ' ', ' ']), ' ', ' ']), ' ', ' ', ' ', ' ', ' ', el('div', { className: 'hidden sm:flex sm:items-center sm:space-x-8' }, [' ', ' ', el('ul', { className: 'flex space-x-4 items-center' }, [' ', ' ', ' ', ' ', el('li', { className: 'has-dropdown group relative' }, [' ', ' ', el('a', { href: '#', className: 'inline-flex items-center text-sm font-medium text-gray-700 hover:text-gray-900 px-3 py-2' }, ['Services ', ' ', el('svg', { className: 'ml-2 h-4 w-4', 'version': '', 'xmlns': '', viewBox: '0 0 20 20', 'xmlSpace': '', fill: 'currentColor', 'stroke': '' }, [' ', el('path', { fillRule: 'evenodd', d: 'M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z', clipRule: 'evenodd' }), ' ']), ' ', ' ']), ' ', ' ', ' ', ' ', el('ul', { className: 'sub-menu hidden absolute left-0 mt-2 w-64 bg-white shadow-lg ring-1 ring-black ring-opacity-5 rounded-md z-50 py-2 group-hover:block' }, [' ', ' ', ' ', ' ']), ' ', ' ']), ' ', ' ', ' ', ' ']), ' ', ' ']), ' ', ' ', ' ', ' ', ' ', el('div', { className: 'hidden sm:flex sm:items-center ml-6' }, [' ', ' ', el(RichText, { tagName: 'a', href: propOrDefault( props.attributes.cta_link.url, 'cta_link', 'url' ), className: 'px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700', onClick: function(e) { e.preventDefault(); }, value: propOrDefault( props.attributes.cta_text, 'cta_text' ), onChange: function(val) { setAttributes( {cta_text: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', ' ']), ' ', ' ']), ' ', ' ']), ' ', ' ']),                        
                
                    el( InspectorControls, {},
                        [
                            
                        pgMediaImageControl('logo', setAttributes, props, 'full', true, 'Site Logo', '' ),
                                        
                            el(Panel, {},
                                el(PanelBody, {
                                    title: __('Block properties')
                                }, [
                                    
                                    el(ToggleControl, {
                                        checked: props.attributes.site_title_display === '',
                                        label: __( 'Show Site Title' ),
                                        onChange: function(val) { setAttributes({site_title_display: val ? '' : ''}) },
                                        help: __( '' ),
                                    }),
                                    pgUrlControl('cta_link', setAttributes, props, 'CTA Button Link', '', null ),
                                    el(TextControl, {
                                        value: props.attributes.cta_text,
                                        help: __( '' ),
                                        label: __( 'CTA Button Text' ),
                                        onChange: function(val) { setAttributes({cta_text: val}) },
                                        type: 'text'
                                    }),    
                                ])
                            )
                        ]
                    )                            

            ]);
        },

        save: function(props) {
            return null;
        }                        

    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor
);                        
