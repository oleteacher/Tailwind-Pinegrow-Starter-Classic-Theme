<?php

        PG_Blocks_v3::register_block_type( array(
            'name' => 'starter-classic-theme-tailwind/services',
            'title' => __( 'Services', 'starter_classic_theme_tailwind' ),
            'description' => __( 'Display services with icons and descriptions', 'starter_classic_theme_tailwind' ),
            'category' => 'custom_blocks',
            'render_template' => 'blocks/services/services.php',
            'supports' => array(),
            'base_url' => get_template_directory_uri(),
            'base_path' => get_template_directory(),
            'js_file' => 'blocks/services/services.js',
            'attributes' => array(
                'heading' => array(
                    'type' => array('string', 'null'),
                    'default' => 'Our Services'
                ),
                'subheading' => array(
                    'type' => array('string', 'null'),
                    'default' => 'We provide comprehensive solutions to make your remote work experience seamless and productive.'
                )
            ),
            'example' => array(
'heading' => 'Our Services', 'subheading' => 'We provide comprehensive solutions to make your remote work experience seamless and productive.'
            ),
            'dynamic' => true,
            'has_inner_blocks' => true,
            'version' => '1.0.357'
        ) );
