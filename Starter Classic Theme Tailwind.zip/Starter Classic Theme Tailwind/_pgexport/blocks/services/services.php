<section <?php if(empty($_GET['context']) || $_GET['context'] !== 'edit') echo get_block_wrapper_attributes( array('class' => "py-16 md:py-24 bg-slate-50", ) ); else echo 'data-wp-block-props="true"'; ?>> 
    <div class="container mx-auto px-4"> 
        <div class="text-center mb-16"> 
            <h2 class="text-3xl md:text-4xl font-bold mb-4"><?php echo PG_Blocks_v3::getAttribute( $args, 'heading' ) ?></h2> 
            <p class="text-slate-600 max-w-2xl mx-auto"><?php echo PG_Blocks_v3::getAttribute( $args, 'subheading' ) ?></p> 
        </div>         
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8" <?php if(!empty($_GET['context']) && $_GET['context'] === 'edit') echo 'data-wp-inner-blocks'; ?>>
            <?php if(empty($_GET['context']) || $_GET['context'] !== 'edit') echo PG_Blocks_v3::getInnerContent( $args ); ?>
        </div>         
    </div>     
</section>