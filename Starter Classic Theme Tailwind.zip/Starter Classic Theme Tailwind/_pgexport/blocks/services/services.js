
( function ( blocks, element, blockEditor ) {
    const el = element.createElement,
        registerBlockType = blocks.registerBlockType,
        ServerSideRender = PgServerSideRender3,
        InspectorControls = blockEditor.InspectorControls,
        useBlockProps = blockEditor.useBlockProps;
        
    const {__} = wp.i18n;
    const {ColorPicker, TextControl, ToggleControl, SelectControl, Panel, PanelBody, Disabled, TextareaControl, BaseControl} = wp.components;
    const {useSelect} = wp.data;
    const {RawHTML, Fragment} = element;
   
    const {InnerBlocks, URLInputButton, RichText} = wp.blockEditor;
    const useInnerBlocksProps = blockEditor.useInnerBlocksProps || blockEditor.__experimentalUseInnerBlocksProps;
    
    const propOrDefault = function(val, prop, field) {
        if(block.attributes[prop] && (val === null || val === '')) {
            return field ? block.attributes[prop].default[field] : block.attributes[prop].default;
        }
        return val;
    }
    
    const block = registerBlockType( 'starter-classic-theme-tailwind/services', {
        apiVersion: 2,
        title: 'Services',
        description: 'Display services with icons and descriptions',
        icon: 'block-default',
        category: 'custom_blocks',
        keywords: [],
        supports: {},
        attributes: {
            heading: {
                type: ['string', 'null'],
                default: `Our Services`,
            },
            subheading: {
                type: ['string', 'null'],
                default: `We provide comprehensive solutions to make your remote work experience seamless and productive.`,
            }
        },
        example: { attributes: { heading: `Our Services`, subheading: `We provide comprehensive solutions to make your remote work experience seamless and productive.` } },
        edit: function ( props ) {
            const blockProps = useBlockProps({ className: 'py-16 md:py-24 bg-slate-50' });
            const setAttributes = props.setAttributes; 
            
            
            const innerBlocksProps = useInnerBlocksProps({ className: 'grid grid-cols-1 md:grid-cols-3 gap-8' }, {
                allowedBlocks: [ 'starter-classic-theme-tailwind/service-item' ],
                template: [
    [ 'starter-classic-theme-tailwind/service-item', {} ],
    [ 'starter-classic-theme-tailwind/service-item', {} ],
    [ 'starter-classic-theme-tailwind/service-item', {} ]
],
            } );
                            
            
            return el(Fragment, {}, [
                el('section', { ...blockProps }, [' ', ' ', el('div', { className: 'container mx-auto px-4' }, [' ', ' ', el('div', { className: 'text-center mb-16' }, [' ', ' ', el(RichText, { tagName: 'h2', className: 'text-3xl md:text-4xl font-bold mb-4', value: propOrDefault( props.attributes.heading, 'heading' ), onChange: function(val) { setAttributes( {heading: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', ' ', el(RichText, { tagName: 'p', className: 'text-slate-600 max-w-2xl mx-auto', value: propOrDefault( props.attributes.subheading, 'subheading' ), onChange: function(val) { setAttributes( {subheading: val }) }, withoutInteractiveFormatting: true, allowedFormats: [] }), ' ', ' ']), ' ', ' ', el('div', { ...innerBlocksProps }), ' ', ' ']), ' ', ' ']),                        
                
                    el( InspectorControls, {},
                        [
                            
                            el(Panel, {},
                                el(PanelBody, {
                                    title: __('Block properties')
                                }, [
                                    
                                    el(TextControl, {
                                        value: props.attributes.heading,
                                        help: __( '' ),
                                        label: __( 'Section Heading' ),
                                        onChange: function(val) { setAttributes({heading: val}) },
                                        type: 'text'
                                    }),
                                    el(TextControl, {
                                        value: props.attributes.subheading,
                                        help: __( '' ),
                                        label: __( 'Section Subheading' ),
                                        onChange: function(val) { setAttributes({subheading: val}) },
                                        type: 'text'
                                    }),    
                                ])
                            )
                        ]
                    )                            

            ]);
        },

            save: function(props) {
                return el(InnerBlocks.Content);
            }                        
    
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor
);                        
